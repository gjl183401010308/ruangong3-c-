﻿#include<iostream>
#include<stdio.h>
#include<math.h>
const double DEGREE = 3.14 / 180;
using namespace std;
class Count
{
public:
	void Plus();
	void Minus();
	void Multiply();
	void Divide();
	void Square();
	void Sqrtt();
	void Trifunc();
	void Isprime();
	long long Jiecheng(int y);
	void Trans();
private:
	double P;
};
void Count::Plus()
{
	cout << "请输入两个要进行相加的数：" << endl;
	double x1, y1;
	cin >> x1 >> y1;
	double x;
	x = x1 + y1;
	P = x;
	printf("%.2lf + %.2lf = %.2lf\n", x1, y1, x);
	while (1)
	{
		cout << "是否继续进行相加  继续请按1，否定请按0" << endl;
		int m;
		cin >> m;
		if (m == 1) {
			cout << "请继续输入一个要进行相加的数：" << endl;
			double x2, b;
			b = P;
			cin >> x2;
			P += x2;
			printf("%.2lf + %.2lf = %.2lf\n", b, x2, P);
		}
		else
			return;
	}
}
void Count::Minus()
{
	cout << "请依次输入被减数和减数：" << endl;
	double x2, y2;
	cin >> x2 >> y2;
	double x;
	x = x2 - y2;
	P = x;
	printf("%.2lf - %.2lf = %.2lf\n", x2, y2, x);
	while (1)
	{
		cout << "是否继续进行相减  继续请按1，否定请按0" << endl;
		int m;
		cin >> m;
		if (m == 1)
		{
			cout << "请输入一个减数：" << endl;
			double x1, b;
			b = P;
			cin >> x1;
			P -= x1;
			printf("%.2lf - %.2lf = %.2lf\n", b, x1, P);
		}
		else
			return;
	}
}
void Count::Multiply()
{
	cout << "请输入两个要进行相乘的数：" << endl;
	double x1, y1;
	cin >> x1 >> y1;
	P = x1 * y1;
	printf("%.2lf * %.2lf = %.2lf\n", x1, y1, P);
	while (1)
	{
		cout << "是否继续进行相乘  继续请按1，否定请按0" << endl;
		int m;
		cin >> m;
		if (m == 1)
		{
			cout << "请输入一个乘数：" << endl;
			double x2, b;
			b = P;
			cin >> x2;
			P *= x2;
			printf("%.2lf * %.2lf = %.2lf\n", b, x2, P);
		}
		else
			return;
	}
}
void Count::Divide()
{
	cout << "请输入两个要进行相除的数：" << endl;
	double x1, y1;
	cin >> x1 >> y1;
	P = x1 / y1;
	printf("%.2lf / %.2lf = %.2lf\n", x1, y1, P);
	while (1)
	{
		cout << "是否继续进行相除  继续请按1，否定请按0" << endl;
		int m;
		cin >> m;
		if (m == 1)
		{
			cout << "请输入一个除数：" << endl;
			double x2, b;
			b = P;
			cin >> x2;
			P /= x2;
			printf("%.2lf / %.2lf = %.2lf\n", b, x2, P);
		}
		else
			return;
	}
}
void Count::Square()
{
	cout << "请输入一个要进行求方的数：" << endl;
	double x1;
	cin >> x1;
	cout << "请输入想要得到" << x1 << "的几次方：" << endl;
	double y1;
	cin >> y1;
	cout << x1 << "的" << y1 << "次方=：";
	cout << pow(x1, y1) << endl;
}
void Count::Sqrtt()
{
	cout << "请输入一个要进行开方的数：" << endl;
	double x1;
	cin >> x1;
	cout << "请输入想要" << x1 << "开几次方：" << endl;
	double y1;
	cin >> y1;
	cout << x1 << "开" << y1 << "次方=：";
	cout << pow(x1, 1 / y1) << endl;

}
void Count::Trifunc()
{
	cout << "请输入进行求解的度数：" << endl;
	double x1;
	cin >> x1;
	printf("功能选项：\n");
	printf("按1求解正弦值；\n");
	printf("按2求解余弦值；\n");
	printf("按3求解正切值；\n");
	printf("按4求解正割值；\n");
	printf("按5求解余割值；\n");
	cout << "请输入要进行求解的方式 rang from 1-->5:" << endl;
	int m;
	while (1) {
		cin >> m;
		if (m == 1) {
			printf("%.2lf 的正弦值为：%.2lf \n", x1, sin(x1 * DEGREE));
			break;
		}
		else if (m == 2) {
			printf("%.2lf 的余弦值为：%.2lf \n", x1, cos(x1 * DEGREE));
			break;
		}
		else if (m == 3) {
			if (int(x1) % 90 == 0)
				printf("输入不合法\n");
			else
				printf("%.2lf 的正切值为：%.2lf \n", x1, tan(x1 * DEGREE));
			break;
		}
		else if (m == 4) {
			printf("%.2lf 的正割值为：%.2lf \n", x1, 1 / cos(x1 * DEGREE));
			break;
		}
		else if (m == 5) {
			printf("%.2lf 的余割值为：%.2lf \n", x1, 1 / sin(x1 * DEGREE));
			break;
		}
		else {
			cout << "暂无此功能，请重新输入一个数：" << endl;
		}
	}
}
void Count::Isprime()
{
	printf("该器的功能为求出这一范围内所有质数并求和；\n");
	cout << "请输入一个范围：" << endl;
	int x1;
	cin >> x1;
	int i, k, sum = 0;
	double num = 0;
	for (i = 2; i <= x1; i++)
	{
		for (k = 2; k < i; k++)
			if (i % k == 0)break;
		if (k >= i) {
			sum++;
			num += i;
			printf("%d ", i);
			if (sum % 10 == 0)
				printf("\n");
		}
	}
	printf("\n");
	cout << "是否将这些素数求和  求和请按1，否定请按0：" << endl;
	int g;
	cin >> g;
	if (g == 1)
		printf("%.2lf\n", num);
	else
		return;
}
long long Count::Jiecheng(int y)
{
	int O = y;
	if (y == 0 || y == 1) {
		printf("%d!=", O);
		return 1;
	}
	long long x = y * (y - 1);
	y--;
	while (y != 1) {
		x = x * (y - 1);
		y--;
	}
	printf("%d!=", O);
	return x;
}
void Count::Trans()
{
	cout << "按1将   十进制   转为其他（二，八，十六）进制：" << endl;
	cout << "按11将   二进制   转为其他（八，十，十六）进制：" << endl;
	cout << "按111将   八进制   转为其他（二，十，十六）进制：" << endl;
	cout << "按1111将   十六进制   转为其他（二，八，十）进制：" << endl;
	int m;
	cin >> m;
	if (m == 1) {
		cout << "请输入一个十进制整数：" << endl;
		int w;
		cin >> w;
		printf("功能选项：\n");
		printf("按2将十进制转为二进制；\n");
		printf("按8将十进制转为八进制；\n");
		printf("按16将十进制转为十六进制；\n");
		cout << "输入一个功能选项 from 2、8、16：" << endl;
		int k;
		while (1) {
			cin >> k;
			if (k == 2) {
				int l = w;
				int a[50], i = 1;
				while (l != 0) {
					a[i] = l % 2;
					l /= 2;
					i++;
				}
				i--;
				cout << "将十进制" << w << "转为2进制的结果为：" << endl;
				for (; i > 0; i--)
					printf("%d", a[i]);
				printf("\n");
				break;
			}
			else if (k == 8) {
				int h = w;
				int b[30] = { 0 }, i = 1;
				while (h != 0) {
					b[i] = h % 8;
					i++;
					h /= 8;
				}
				i--;
				cout << "将十进制" << w << "转为8进制的结果为：" << endl;
				for (; i > 0; i--)
					printf("%d", b[i]);
				printf("\n");
				break;
			}
			else if (k == 16) {
				int d = w;
				int c[20], i = 1;
				while (d != 0) {
					c[i] = d % 16;
					d /= 16;
					i++;
				}
				i--;
				cout << "将十进制" << w << "转为16进制的结果为：" << endl;
				for (; i > 0; i--)
					printf("%d", c[i]);
				printf("\n");
				break;
			}
			else
				cout << "输入错误，请重新输入一个数 from 2、8、16：" << endl;
		}
	}
	else if (m == 11) {
		cout << "请输入一个二进制整数：" << endl;
		int r;
		cin >> r;
		printf("功能选项：\n");
		printf("按8将二进制转为八进制；\n");
		printf("按10将二进制数转为十进制；\n");
		printf("按16将二进制转为十六进制；\n");
		cout << "请输入一个功能选项 from 8、10、16：\n" << endl;
		int p;
		while (1) {
			cin >> p;
			int j = r;
			double v = 0;
			int A[30], i = 1;
			while (j > 0) {
				A[i] = j % 10;
				j /= 10;
				v++;
				i++;
			}
			int a = 0;
			i--;
			v--;
			for (; v >= 0; v--, i--)
				a = a + pow(2, v) * A[i];
			P = a;
			if (p == 8) {
				int q = P;
				int iO = 1;
				int AC[30];
				while (q != 0) {
					AC[iO] = q % 8;
					q /= 8;
					iO++;
				}
				iO--;
				cout << "将二进制" << r << "转为八进制的结果为：" << endl;
				for (; iO > 0; iO--)
					printf("%d", AC[iO]);
				printf("\n");
				break;
			}
			else if (p == 10) {
				cout << "将二进制" << r << "转为十进制的结果为：" << endl;
				cout << P << endl;
				break;
			}
			else if (p == 16) {
				int l = P;
				int B[30], i = 1;
				while (l != 0) {
					B[i] = l % 16;
					l /= 16;
					i++;
				}
				i--;
				cout << "将二进制" << r << "转为十六进制的结果为：" << endl;
				for (; i > 0; i--)
					printf("%d", B[i]);
				printf("\n");
				break;
			}
			else cout << "输入错误,请重新输入一个数from 8、10、16：" << endl;
		}
	}
	else if (m == 111) {
		cout << "请输入一个八进制整数：\n" << endl;
		int mm;
		cin >> mm;
		printf("功能选项：\n");
		printf("按2将八进制转为二进制；\n");
		printf("按10将八进制数转为十进制；\n");
		printf("按16将八进制转为十六进制；\n");
		cout << "请输入一个功能选项 from 2、10、16：\n" << endl;
		int tt;
		while (1) {
			cin >> tt;
			int nb = 0;
			int pp = mm;
			double vv = 0;
			int A[30], ii = 1;
			while (pp > 0) {
				A[ii] = pp % 10;
				pp /= 10;
				vv++;
				ii++;
			}
			int a = 0;
			ii--;
			vv--;
			for (; vv >= 0; vv--, ii--)
				a = a + pow(8, vv) * A[ii];
			P = a;
			if (tt == 2) {
				int qq = P;
				int AA[30];
				ii = 1;
				while (qq != 0) {
					AA[ii] = qq % 2;
					qq /= 2;
					ii++;
				}
				ii--;
				cout << "将八进制" << mm << "转为二进制的结果为：" << endl;
				for (; ii > 0; ii--)
					printf("%d", AA[ii]);
				printf("\n");
				break;
			}
			else if (tt == 10) {
				cout << "将八进制" << mm << "转为十进制的结果为：" << endl;
				cout << P << endl;
				break;
			}
			else if (tt == 16) {
				int ll = P;
				int BB[30], ii = 1;
				while (ll > 0) {
					BB[ii] = ll % 16;
					ll /= 16;
					ii++;
				}
				ii--;
				cout << "将八进制" << mm << "转为十六进制的结果为：" << endl;
				for (; ii > 0; ii--)
					printf("%d", BB[ii]);
				printf("\n");
				break;
			}
			else cout << "输入错误，请重新输入一个数from 2、10、16：" << endl;
		}
	}
	else if (m == 1111) {
		cout << "请输入一个十六进制的整数：" << endl;
		int rr;
		cin >> rr;
		printf("功能选项：\n");
		printf("按2将十六进制转为二进制；\n");
		printf("按8将十六进制数转为八进制；\n");
		printf("按10将十六进制转为十进制；\n");
		cout << "请输入一个功能选项 from 2、8、10：\n" << endl;
		int pp;
		while (1) {
			cin >> pp;
			int jj = rr;
			double v = 0;
			int AP[30], i = 1;
			while (jj > 0) {
				AP[i] = jj % 10;
				jj /= 10;
				v++;
				i++;
			}
			int a = 0;
			i--;
			v--;
			for (; v >= 0; v--, i--)
				a = a + pow(16, v) * AP[i];
			P = a;
			if (pp == 2) {
				int q = P;
				int iD = 1;
				int AD[30];
				while (q != 0) {
					AD[iD] = q % 2;
					q /= 2;
					iD++;
				}
				iD--;
				cout << "将十六进制" << rr << "转为二进制的结果为：" << endl;
				for (; iD > 0; iD--)
					printf("%d", AD[iD]);
				printf("\n");
				break;
			}
			else if (pp == 10) {
				cout << "将十六进制" << rr << "转为十进制的结果为：" << endl;
				cout << P << endl;
				break;
			}
			else if (pp == 8) {
				int l = P;
				int B[30], i = 1;
				while (l != 0) {
					B[i] = l % 8;
					l /= 8;
					i++;
				}
				i--;
				cout << "将十六进制" << rr << "转为八进制的结果为：" << endl;
				for (; i > 0; i--)
					printf("%d", B[i]);
				printf("\n");
				break;
			}
			else cout << "输入错误,请重新输入一个数from 2、8、10：" << endl;
		}
	}
	else cout << "输入错误；" << endl;
}
int main()
{
	printf("hello,有不会的尽管来找我吧！\n");
	printf("\n");
	int i;
	Count M;
	printf("请继续输入你要进行的操作range from 1 to 11 \n");
	printf("menue :\n");
	printf("1-->加法器\n");
	printf("2-->减法器\n");
	printf("3-->乘法器\n");
	printf("4-->除法器\n");
	printf("5-->次方器\n");
	printf("6-->开方器\n");
	printf("7-->三角函数器\n");
	printf("8-->质数器\n");
	printf("9-->阶乘器\n");
	printf("10-->进制转换器\n");
	printf("11-->结束计算\n");
	printf("\n");
	while (1) {
		scanf("%d", &i);
		if (i == 11)
			break;
		else switch (i)
		{
		case 1:M.Plus();
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		case 2:M.Minus();
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		case 3:M.Multiply();
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		case 4:M.Divide();
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		case 5:M.Square();
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		case 6:M.Sqrtt();
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		case 7:M.Trifunc();
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		case 8:M.Isprime();
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		case 9:printf("请输入要进行阶乘计算的数：\n");
			int z;
			cin >> z;
			cout << M.Jiecheng(z) << endl;
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		case 10:M.Trans();
			system("pause");
			system("cls");
			printf("\n");
			printf("请继续输入你要进行的操作range from 1 to 11 \n");
			printf("menue :\n");
			printf("1-->加法器\n");
			printf("2-->减法器\n");
			printf("3-->乘法器\n");
			printf("4-->除法器\n");
			printf("5-->次方器\n");
			printf("6-->开方器\n");
			printf("7-->三角函数器\n");
			printf("8-->质数器\n");
			printf("9-->阶乘器\n");
			printf("10-->进制转换器\n");
			printf("11-->结束计算\n");
			printf("\n");
			break;
		default:printf("暂无该功能，请重选 from 1 to 11\n");
		}
	}
	return 0;
}